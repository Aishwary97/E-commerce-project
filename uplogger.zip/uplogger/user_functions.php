<?php
/*
 * Exit if accessed directly
 */
if (!defined('ABSPATH')) {
    exit;
}

/*
 * Create table "wp_user_activity" when activate plugin
 */
if (!function_exists('ual_user_activity_table_create')) {

    function ual_user_activity_table_create() {
        global $wpdb;
        $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/uplogger/uplogger.php', $markup = true, $translate = true);
        $current_version = $plugin_data['Version'];
        $old_table_name = $wpdb->prefix . "user_activity";
        $table_name = $wpdb->prefix . "ualp_user_activity";
        //table is not created. you may create the table here.
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            $old_table_exist = ual_checkif_table_rename();
            if (!$old_table_exist) {
                $create_table_query = "CREATE TABLE $table_name (uactid bigint(20) unsigned NOT NULL auto_increment,post_id int(20) unsigned NOT NULL,post_title varchar(250) NOT NULL,user_id bigint(20) unsigned NOT NULL default '0',user_name varchar(50) NOT NULL,user_role varchar(50) NOT NULL,user_email varchar(50) NOT NULL,ip_address varchar(50) NOT NULL,modified_date datetime NOT NULL default '0000-00-00 00:00:00',object_type varchar(50) NOT NULL default 'post',action varchar(50) NOT NULL,PRIMARY KEY (uactid))";
                require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
                dbDelta($create_table_query);
            } else {
                $wpdb->query("RENAME TABLE " . $old_table_name . " TO " . $table_name);
            }
        }
        update_option('ual_version', $current_version);
    }

}
add_action('activate_plugin', 'ual_user_activity_table_create');

/*
 * Rename table "user_activity" to "ualp"
 */
if (!function_exists('ual_checkif_table_rename')) {

    function ual_checkif_table_rename() {
        global $wpdb;
        $old_table_name = $wpdb->prefix . "user_activity";
        $table_name = $wpdb->prefix . "ualp_user_activity";
        if ($wpdb->get_var("SHOW TABLES LIKE '$old_table_name'") == $old_table_name) {
            if ($wpdb->get_var("SHOW COLUMNS FROM " . $old_table_name . " LIKE 'uactid'") == 'uactid') {
                return true;
            }
            return false;
        }
        return false;
    }

}


/*
 * Insert record into wp_user_activity table
 *
 * @param int $post_id Post ID.
 * @param string $post_title Post Title.
 * @param string $obj_type Object Type (Plugin, Post, User etc.).
 * @param int $current_user_id current user id.
 * @param string $current_user current user name.
 * @param string $user_role current user Role.
 * @param string $user_mail current user Email address.
 * @param datetime $modified_date current user's modified time.
 * @param string $ip current user's IP address.
 * @param string $action current user's activity name.
 *
 */
if (!function_exists('ual_user_activity_add')) {

    function ual_user_activity_add($post_id, $post_title, $obj_type, $current_user_id, $current_user, $user_role, $user_mail, $modified_date, $ip, $action) {
        global $wpdb;
        $table_name = $wpdb->prefix . "ualp_user_activity";
        $post_title = addslashes($post_title);
        if($obj_type == '') {
            $obj_type = 'post';
        }
        $insert_query = $wpdb->insert(
            $table_name,
            array(
                'post_id' => $post_id,
                'post_title' => $post_title,
                'user_id' => $current_user_id,
                'user_name' => $current_user,
                'user_role' => $user_role,
                'user_email' => $user_mail,
                'ip_address' => $ip,
                'modified_date' => $modified_date,
                'object_type' => $obj_type,
                'action' => $action,
            )
        );
    }

}

/*
 * Get activity
 *
 * @param string $action current user's activity name.
 * @param string $obj_type Object Type (Plugin, Post, User etc.).
 * @param int $post_id Post ID.
 * @param string $post_title Post Title.
 *
 */
if (!function_exists('ual_get_activity_function')) {

    function ual_get_activity_function($action, $obj_type, $post_id, $post_title) {
        $current_user_id = $current_user_display_name = $user_mail = $user_role = $modified_date = '';
        $modified_date = current_time('mysql');
        $ip = $_SERVER['REMOTE_ADDR'];
        $current_user_id = get_current_user_id();
        $user = new WP_User($current_user_id);
        $user_mail = $user->user_email;
        global $wp_roles;
        $role_name = array();
        if (!empty($user->roles) && is_array($user->roles)) {
            foreach ($user->roles as $user_r) {
                $role_name[] = $wp_roles->role_names[$user_r];
            }
            $user_role = implode(', ', $role_name);
        }

        $current_user_display_name = $user->display_name;
        ual_user_activity_add($post_id, $post_title, $obj_type, $current_user_id, $current_user_display_name, $user_role, $user_mail, $modified_date, $ip, $action);
    }

}
/*
 * Get logout activity
 *
 * @param string $action current user's activity name.
 * @param string $obj_type Object Type (Plugin, Post, User etc.).
 * @param int $post_id Post ID.
 * @param string $post_title Post Title.
 *
 */
if (!function_exists('ual_get_logout_activity_function')) {

    function ual_get_logout_activity_function($action, $obj_type, $post_id, $post_title) {
        $current_user_id = $current_user_display_name = $user_mail = $user_role = $modified_date = '';
        $modified_date = current_time('mysql');
        $ip = $_SERVER['REMOTE_ADDR'];
        $current_user_id = $post_id;
        $user = new WP_User($current_user_id);
        $user_mail = $user->user_email;
        global $wp_roles;
        $role_name = array();
        if (!empty($user->roles) && is_array($user->roles)) {
            foreach ($user->roles as $user_r) {
                $role_name[] = $wp_roles->role_names[$user_r];
            }
            $user_role = implode(', ', $role_name);
        }

        $current_user_display_name = $user->display_name;
        ual_user_activity_add($post_id, $post_title, $obj_type, $current_user_id, $current_user_display_name, $user_role, $user_mail, $modified_date, $ip, $action);
    }

}

/*
 * Add activity for the current user when login
 *
 * @param string $user_login current user's login name.
 *
 */
if (!function_exists('ual_shook_wp_login')):

    function ual_shook_wp_login($user_login, $user) {
        global $wpdb;
        $action = "logged in";
        $obj_type = "user";
        $user_mail = $user->user_email;
        $current_user_id = $user->ID;
        $user = new WP_User($current_user_id);
        if (!empty($user->roles) && is_array($user->roles)) {
            foreach ($user->roles as $role)
                $user_role = $role;
        }
        $post_id = $current_user_id;
        $post_title = $user_login;
        $modified_date = current_time('mysql');
        $ip = $_SERVER['REMOTE_ADDR'];
        $current_user_display_name = $user->display_name;
        ual_user_activity_add($post_id, $post_title, $obj_type, $current_user_id, $current_user_display_name, $user_role, $user_mail, $modified_date, $ip, $action);
    }

endif;

/*
 * Get activity for the current user when logout
 */
if (!function_exists('ual_shook_wp_logout')):

    function ual_shook_wp_logout($redirect_to, $requested_redirect_to, $user) {
        $action = "logged out";
        $obj_type = "user";
        if(isset($user) && !empty($user)){
            $post_id = $user->data->ID;
            $post_title = $user->data->display_name;
        } else {
            $post_id = "";
            $post_title = "Guest";
        }
        ual_get_logout_activity_function($action, $obj_type, $post_id, $post_title);
        $requested_redirect_to = wp_login_url( get_permalink() );
        return $requested_redirect_to;
    }
endif;

/*
 * Get activity for the delete user
 *
 * @param int $user Post ID
 *
 */
if (!function_exists('ual_shook_delete_user')):

    function ual_shook_delete_user($user) {
        $action = "delete user";
        $obj_type = "user";
        $post_id = $user;
        $user_nm = get_user_by('id', $post_id);
        $post_title = $user_nm->user_login;
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
    }

endif;

/*
 * Get activity for the registered user
 *
 * @param int $user Post ID
 *
 */
if (!function_exists('ual_shook_user_register')):

    function ual_shook_user_register($user) {
        $action = "user register";
        $obj_type = "user";
        $post_id = $user;
        $user_nm = get_user_by('id', $post_id);
        $post_title = $user_nm->user_login;
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
    }

endif;

/*
 * Get activity for the user - update profile
 *
 * @param int $user Post ID
 *
 */
if (!function_exists('ual_shook_profile_update')):

    function ual_shook_profile_update($user) {
        $action = "profile update";
        $obj_type = "user";
        $post_id = $user;
        $user_nm = get_user_by('id', $post_id);
        $post_title = $user_nm->user_login;
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
    }

endif;

/*
 * Get activity for the user - add attach media file
 *
 * @param int $attach Post ID
 *
 */
if (!function_exists('ual_shook_add_attachment')):

    function ual_shook_add_attachment($attach) {
        $action = "added attachment";
        $obj_type = "attachment";
        $post_id = $attach;
        $post_title = get_the_title($post_id);
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
    }

endif;

/*
 * Get activity for the user - edit attach media file
 *
 * @param int $attach Post ID
 *
 */
if (!function_exists('ual_shook_edit_attachment')):

    function ual_shook_edit_attachment($attach) {
        $post_id = $attach;
        $post_title = get_the_title($post_id);
        $action = "updated attachment";
        $obj_type = "attachment";
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
    }

endif;

/*
 * Get activity for the user - delete attach media file
 *
 * @param int $attach Post ID
 *
 */
if (!function_exists('ual_shook_delete_attachment')):

    function ual_shook_delete_attachment($attach) {
        $post_id = $attach;
        $post_title = get_the_title($post_id);
        $action = "deleted attachment";
        $obj_type = "attachment";
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
    }

endif;

/*
 * Get activity for the post - delete post file
 *
 * @param int $post Post ID
 *
 */

if (!function_exists('ual_shook_delete_post')):

    function ual_shook_delete_post($post) {
        global $post_type;
        if(did_action( 'before_delete_post' ) == 1){
            $action = "delete ".$post_type;
            $obj_type = $post_type;
            $post_id = $post;
            $post_title = get_the_title($post_id);
            ual_get_activity_function($action, $obj_type, $post_id, $post_title);
        }
       
    }

endif;
/*
 * Get activity for the user - Insert Comment
 *
 * @param int $comment Comment ID
 *
 */
if (!function_exists('ual_shook_wp_insert_comment')):

    function ual_shook_wp_insert_comment($comment) {
        $action = "insert comment";
        $obj_type = "comment";
        $comment_id = $comment;
        $com = get_comment($comment_id);
        $post_id = $com->comment_post_ID;
        $post_link = get_the_permalink($post_id);
        $post_title = "Comment inserted in <a target='blank' href='$post_link'>" . get_the_title($post_id) . "</a>";
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
    }

endif;

/*
 * Get activity for the user - Edit Comment
 *
 * @param int $comment Comment ID
 *
 */
if (!function_exists('ual_shook_edit_comment')):

    function ual_shook_edit_comment($comment) {
        $action = "update comment";
        $obj_type = "comment";
        $comment_id = $comment;
        $com = get_comment($comment_id);
        $post_id = $com->comment_post_ID;
        $post_link = get_the_permalink($post_id);
        $post_title = "Comment updated in <a target='blank' href='$post_link'>" . get_the_title($post_id) . "</a>";
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
    }

endif;

/*
 * Get activity for the user - Trash Comment
 *
 * @param int $comment Comment ID
 *
 */
if (!function_exists('ual_shook_trash_comment')):

    function ual_shook_trash_comment($comment) {
        $action = "trash comment";
        $obj_type = "comment";
        $comment_id = $comment;
        $com = get_comment($comment_id);
        $post_id = $com->comment_post_ID;
        $post_title = "Comment deleted from ".get_the_title($post_id);
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
    }

endif;

/*
 * Get activity for the user - Spam Comment
 *
 * @param int $comment Comment ID
 *
 */
if (!function_exists('ual_shook_spam_comment')):

    function ual_shook_spam_comment($comment) {
        $action = "spam comment";
        $obj_type = "comment";
        $comment_id = $comment;
        $com = get_comment($comment_id);
        $post_id = $com->comment_post_ID;
        $post_title = get_the_title($post_id);
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
    }

endif;

/*
 * Get activity for the user - Unspam Comment
 *
 * @param int $comment Comment ID
 *
 */
if (!function_exists('ual_shook_unspam_comment')):

    function ual_shook_unspam_comment($comment) {
        $action = "unspam comment";
        $obj_type = "comment";
        $comment_id = $comment;
        $com = get_comment($comment_id);
        $post_id = $com->comment_post_ID;
        $post_title = get_the_title($post_id);
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
    }

endif;

/*
 * Get activity for the user - Delete Comment
 *
 * @param int $comment Comment ID
 *
 */
if (!function_exists('ual_shook_delete_comment')):

    function ual_shook_delete_comment($comment) {
        $action = "delete comment";
        $obj_type = "comment";
        $comment_id = $comment;
        $com = get_comment($comment_id);
        $post_id = $com->comment_post_ID;
        $post_title = get_the_title($post_id);
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
    }

endif;


/*
 * Get activity for the user - Comment status change
 *
 * @param string $new_status New status of comment
 * @param string $old_status Old status of comment
 * @param int $comment_id Comment ID
 *
 */
if (!function_exists('ual_hook_status_comment')){

    function ual_hook_status_comment($new_status, $old_status, $comment_id) {
        $obj_type = "Comment";
        $com = get_comment($comment_id);
        $post_id = $com->comment_post_ID;
        $comment_detail_ary = array();
        $comment_detail_ary['ual_comment'] = $com->comment_content;
        $post_title = get_the_title($post_id);
        $post_link = get_the_permalink($post_id);
        if($new_status == 'approved') {
            if($old_status == 'trash' || $old_status == 'spam') {
                $action = 'restored';
                $hook = "restore_comment";
                ual_get_activity_function($action, $obj_type, $post_id, $post_title);
            }
            else {
                $action = 'approved';
                $description = "$obj_type $action in <a target='blank' href='$post_link'>$post_title</a>";
                $hook = "comment_approve";
                ual_get_activity_function($action, $obj_type, $post_id, $post_title);
            }
        }
        else if($new_status == 'unapproved') {
            if($old_status == 'trash' || $old_status == 'spam') {
                $action = 'restored';
                $description = "$obj_type $action from $old_status in <a target='blank' href='$post_link'>$post_title</a>";
                $hook = "restore_comment";
                ual_get_activity_function($action, $obj_type, $post_id, $post_title);
            }
            else {
                $action = "unapproved";
                $description = "$obj_type $action in <a target='blank' href='$post_link'>$post_title</a>";
                $hook = "comment_unapprove";
                ual_get_activity_function($action, $obj_type, $post_id, $post_title);
            }
        }
    }
}

add_action('transition_comment_status', 'ual_hook_status_comment',10,3);

/*
 * Get activity for the user - Create Terms
 *
 * @param int $term Post ID
 * @param string $taxonomy taxonomy name
 *
 */
if (!function_exists('ual_shook_created_term')):

    function ual_shook_created_term($term, $taxonomy) {

        if ('nav_menu' === $taxonomy)
            return $term;
        global $wpdb;
        $post_id = '';
        $taxonomy_details = get_taxonomy($taxonomy);
        $action = "created ".$taxonomy_details->label;
        $obj_type = "term";
        $post_title = $taxonomy_details->label . " - " . $term;
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
        return $term;
    }

endif;

/*
 * Get activity for the user - Edit Terms
 *
 * @param int $term Post ID
 * @param string $taxonomy taxonomy name
 *
 */
if (!function_exists('ual_shook_edited_term')):

    function ual_shook_edited_term($term, $ttid, $taxonomy) {
      
        $obj_type = "term";
        if ('nav_menu' === $taxonomy)
            return;
        global $wpdb;
        $post_id = $term;
        $termName = get_term_by("id", $term, $taxonomy);
        $taxonomy_details = get_taxonomy($taxonomy);
        $action = "Updated term ".$taxonomy_details->label;
        $post_title = $taxonomy_details->label . " - " . $termName->name;
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
    }

endif;

/*
 * Get activity for the user - Delete Terms
 *
 * @param int $term Term ID
 * @param string $taxonomy taxonomy name
 *
 */
if (!function_exists('ual_shook_delete_term')):

    function ual_shook_delete_term($term, $taxonomy) {
        if ('nav_menu' === $taxonomy)
            return;

        if ($taxonomy && !is_wp_error($taxonomy)) {
            $taxonomy_details = get_taxonomy($taxonomy);
            $action = 'delete term '.$taxonomy_details->label;
            $obj_type = 'Term';
            $termName = get_term_by("id", $term, $taxonomy);
            $post_title = $taxonomy_details->label . " - " . $termName->name;
            ual_get_activity_function($action, $obj_type, $term, $post_title);
        }
    }

endif;

/*
 * Get activity for the user - Update navigation menu
 *
 * @param int $menu Post ID
 *
 */
if (!function_exists('ual_shook_wp_update_nav_menu')):

    function ual_shook_wp_update_nav_menu($menu) {
        if(!isset($_REQUEST["menu"]) || !isset($_REQUEST["action"])) {
            return;
        }
        if($_REQUEST["action"]!= "delete" && $_REQUEST["action"]!= "locations" && $_REQUEST["action"] != "update") {
            return;
        }
        $menu_id = intval($_REQUEST["menu"]);
        if(!is_nav_menu($menu_id)) {
            return;
        }
        $menu_object = wp_get_nav_menu_object($menu_id);
        $obj_type = "Menu";
        $post_id = $menu_id;
        $post_title = $menu_object->name;
    
        if("delete" == $_REQUEST["action"]) {
            $action = "Deleted nav menu";
            ual_get_activity_function($action, $obj_type, $post_id, $post_title);
        } elseif("locations" == $_REQUEST["action"]) {
            $action = "Updated nav menu location";
            ual_get_activity_function($action, $obj_type, $post_id, $post_title);
        } else {
            $action = "Update nav menu";
            ual_get_activity_function($action, $obj_type, $post_id, $post_title);
        }
    }

endif;

/*
 * Get activity for the user - Create navigation menu
 *
 * @param int $menu Post ID
 *
 */
if (!function_exists('ual_shook_wp_create_nav_menu')):

    function ual_shook_wp_create_nav_menu($menu) {
        $action = "created nav menu";
        $obj_type = "menu";
        $post_id = $menu;
        $menu_object = wp_get_nav_menu_object($post_id);
        $post_title = $menu_object->name;
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
    }

endif;

/*
 * Get activity for the user - Switch Theme
 *
 * @param string $theme Post Title
 *
 */
if (!function_exists('ual_shook_switch_theme')):

    function ual_shook_switch_theme($theme) {
        $action = "switch theme";
        $obj_type = "theme";
        $post_id = "";
        $post_title = $theme;
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
    }

endif;

/*
 * Get activity for the user - Update Theme
 *
 */
if (!function_exists('shook_delete_site_transient_update_themes')):

    function shook_delete_site_transient_update_themes() {
        $action = "delete_site_transient_update_themes";
        $obj_type = "theme";
        $post_id = "";
        $post_title = $theme;
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
    }

endif;

/*
 * Get activity for the user - Customize Theme
 *
 */
if (!function_exists('ual_shook_customize_save')):

    function ual_shook_customize_save() {
        $action = "customize save";
        $obj_type = "theme";
        $post_id = "";
        $post_title = "Theme Customizer";
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
    }

endif;

/*
 * Get activity for the user - Activate Plugin
 *
 * @param string $plugin Post Title
 *
 */
if (!function_exists('ual_shook_activated_plugin')):

    function ual_shook_activated_plugin($plugin) {

        $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin, true, false);
        $post_title = $plugin_data['Name'];
        $action = "Plugin activated";
        $obj_type = "plugin";
        $post_id = "";
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
    }

endif;

if(!function_exists('ualHookBeforeEditPost')) {

    function ualHookBeforeEditPost($post_ID) {
        global $old_post_data;
        if (!current_user_can('edit_post',$post_ID)) {
            return;
        };        
        $prev_post_data = get_post($post_ID);
        $post_type = $prev_post_data->post_type;
        $post_tax = '';
        if($post_type != '' && $post_type != 'nav_menu_item') {
            $taxonomy_names = get_object_taxonomies( $post_type );
            if(is_array($taxonomy_names) && !empty($taxonomy_names)) {
                foreach($taxonomy_names as $taxonomy_name) {
                    $post_cats = wp_get_post_terms($post_ID, $taxonomy_name);
                    $post_cats_ids = array();
                    foreach($post_cats as $post_cat) {
                        $post_cats_ids[] = $post_cat->term_id;
                    }
                    if(is_array($post_cats_ids) && !empty($post_cats_ids)) {
                        $post_tax[$taxonomy_name] = $post_cats_ids;
                    }
                }
            }
        }
        $old_post_data = array(
            "post_data" => $prev_post_data,
            "post_meta" => get_post_custom($post_ID),
            "post_tax" => $post_tax
        );
    }
}
add_action("pre_post_update","ualHookBeforeEditPost",10);

/*
 * Get activity for the user - Activate Plugin
 *
 * @param string $new_status new posts status
 * @param string $old_status old posts status
 * @param object $post posts
 *
 */
if (!function_exists('ual_shook_transition_post_status')){

    function ual_shook_transition_post_status($post_id, $post) {
        global $old_post_data;
        $old_post_data_detail = $old_post_data['post_data'];
        if(isset($old_post_data_detail) && $old_post_data_detail != ''){
            $oldstatus = $old_post_data_detail->post_status;
        }
        $newstatus = $post->post_status;
        $old_status = isset($oldstatus) ? $oldstatus : '';
        $new_status = isset($newstatus) ? $newstatus : '';
        $obj_type = $post->post_type;
        $post_id = $post->ID;
        $post_title = $post->post_title;

        if ("nav_menu_item" == get_post_type($post) || "wpcf7_contact_form" == get_post_type($post) || wp_is_post_revision($post) || $obj_type == 'customize_changeset') {
            return;
        }
        if ( wp_is_post_revision( $post->ID ) ){
            return;   
        }
        $user = wp_get_current_user();
        $roles = $user->roles;
        if ( 'auto-draft' === $new_status || ( 'new' === $old_status && 'inherit' === $new_status ) ) {
            return;
        } elseif ( 'auto-draft' === $old_status && $new_status === 'draft' ) {
            $action = $obj_type .' drafted';
        } elseif ( 'draft' === $old_status && $new_status === 'publish' && $old_post_data['post_data']->post_date_gmt === '0000-00-00 00:00:00') {
            $action = $obj_type .' created';
        } elseif ( 'trash' === $new_status ) {
            $action = $obj_type .' trashed';
        } elseif ( 'trash' === $old_status ) {
            $action = $obj_type .' restored';
        } elseif ('publish' === $old_status && 'draft' != $old_status) { 
            $action = $obj_type .' updated';
        } else if ('publish' === $new_status && 'draft' != $old_status) {
            $action = $obj_type .' created';
        } else if ('publish' != $new_status && 'draft' == $old_status) {
            $action = $obj_type .' drafted';
        } else {
            $action = $obj_type .' updated';
        }
        foreach($roles as $role){
            if($role == 'contributor'){
                $action = $obj_type .' is submit for review';
            }
        }
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
    }
}
/*
 * Get activity for the user - Deactivate Plugin
 *
 * @param string $plugin Post Title
 *
 */
if (!function_exists('ual_shook_deactivated_plugin')):

    function ual_shook_deactivated_plugin($plugin) {
        $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin, true, false);
        $post_title = $plugin_data['Name'];
        $action = "Plugin deactivated";
        $obj_type = "plugin";
        $post_id = "";
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
    }

endif;

/*
 * Get activity for the user - Core file updated successfully
 *
 */
if (!function_exists('shook_core_updated_successfully')):

    function shook_core_updated_successfully() {
        $action = "core updated successfully";
        $obj_type = "update";
        $post_id = "";
        $post_title = $obj_type;
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
    }

endif;

/*
 * Get activity for the user - Export wordpress data
 *
 */
if (!function_exists('ual_shook_export_wp')):

    function ual_shook_export_wp($args) {
        $content = isset( $args['content'] ) ? $args['content'] : 'all';
        $action = $content." Downloaded";
        $obj_type = "Export";
        $post_id = "";
        $post_title = $obj_type . ' : ' . $content;
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
    }

endif;

/*
 * Get activity for the user - Upgrader process complete
 *
 */
if (!function_exists('shook_upgrader_process_complete')):

    function shook_upgrader_process_complete() {
        $action = "upgrade process complete";
        $obj_type = "upgrade";
        $post_id = "";
        $post_title = $obj_type;
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
    }

endif;

/*
 * Get activity for the user - Delete theme
 *
 */
if (!function_exists('ual_shook_theme_deleted')):

    function ual_shook_theme_deleted() {
        $backtrace_history = debug_backtrace();
        $delete_theme_call = null;
        foreach ($backtrace_history as $call) {
            if (isset($call['function']) && 'delete_theme' === $call['function']) {
                $delete_theme_call = $call;
                break;
            }
        }
        if (empty($delete_theme_call))
            return;
        $name = $delete_theme_call['args'][0];
        $action = 'Theme deleted';
        $obj_type = 'Theme';
        $post_title = $name;
        $post_id = "";
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
    }

endif;

add_action('wp_login', 'ual_shook_wp_login', 20, 2);
add_filter('logout_redirect', 'ual_shook_wp_logout', 10, 3);
add_action('delete_user', 'ual_shook_delete_user');
add_action('before_delete_post', 'ual_shook_delete_post', 10, 1);
add_action('user_register', 'ual_shook_user_register');
add_action('profile_update', 'ual_shook_profile_update');
add_action('add_attachment', 'ual_shook_add_attachment');
add_action('edit_attachment', 'ual_shook_edit_attachment');
add_action('delete_attachment', 'ual_shook_delete_attachment');
add_action('wp_insert_comment', 'ual_shook_wp_insert_comment');
add_action('edit_comment', 'ual_shook_edit_comment');
add_action('trash_comment', 'ual_shook_trash_comment');
add_action('spam_comment', 'ual_shook_spam_comment');
add_action('unspam_comment', 'ual_shook_unspam_comment');
add_action('delete_comment', 'ual_shook_delete_comment');
add_action("load-nav-menus.php", 'ual_shook_wp_update_nav_menu');
add_action('wp_create_nav_menu', 'ual_shook_wp_create_nav_menu');
add_action('activated_plugin', 'ual_shook_activated_plugin');
add_action('deactivated_plugin', 'ual_shook_deactivated_plugin');
//add_action('created_term', 'ual_shook_created_term', 10, 2);
add_filter('pre_insert_term', 'ual_shook_created_term', 10, 2);
add_action('edited_term', 'ual_shook_edited_term', 10, 3);
add_action('pre_delete_term', 'ual_shook_delete_term', 10, 2);
add_action('switch_theme', 'ual_shook_switch_theme');
add_action('customize_save', 'ual_shook_customize_save');
add_action('export_wp', 'ual_shook_export_wp');
add_action('save_post', 'ual_shook_transition_post_status', 100, 2);
add_action('delete_site_transient_update_themes', 'ual_shook_theme_deleted');

/*
 * Get activity for the user - Login fail
 *
 * @param string $user username
 */
if (!function_exists('ual_shook_wp_login_failed')):

    function ual_shook_wp_login_failed($user) {
        $current_user_id = $post_id = $user_mail = $current_user_display_name = $user_role = "";
        $action = "login failed";
        $obj_type = "user";
        $post_title = $user;
        $modified_date = current_time('mysql');
        $ip = $_SERVER['REMOTE_ADDR'];
        $user_detail = get_user_by('login', $user);
        if (isset($user_detail) && $user_detail != '') {
            $current_user_id = $user_detail->ID;
            $user_mail = $user_detail->user_email;
            $current_user_display_name = $user_detail->display_name;
            if (!empty($user_detail->roles) && is_array($user_detail->roles)) {
                foreach ($user_detail->roles as $role)
                    $user_role = $role;
            }
        }
        ual_user_activity_add($post_id, $post_title, $obj_type, $current_user_id, $current_user_display_name, $user_role, $user_mail, $modified_date, $ip, $action);
    }

endif;
add_action('wp_login_failed', 'ual_shook_wp_login_failed');

/*
 * Get activity for the user - Widget update
 *
 * @param string $widget widget data
 */
if (!function_exists('ual_shook_widget_update_callback')):

    function ual_shook_widget_update_callback($instance, $new_instance, $old_instance, $widget_instance) {

        if (empty($old_instance)) {
            return $instance;
        }
        $action = "widget updated";
        $obj_type = "widget";
        $post_id = $sidebar = $sidebar_name = '';
        $sidebar_id = intval($_POST["sidebar"]);
        $sidebars = isset($GLOBALS['wp_registered_sidebars']) ? $GLOBALS['wp_registered_sidebars'] : false;

        if ($sidebars) {
            if (isset($sidebars[$sidebar_id])) {
                $sidebar = $sidebars[$sidebar_id];
            }
            if(isset($sidebar["name"])){
                $sidebar_name = $sidebar["name"];
            }
        }
        $post_title = $sidebar_name . ' : ' . $widget_instance->name;
        ual_get_activity_function($action, $obj_type, $post_id, $post_title);
        return $instance;
    }

endif;
add_filter('widget_update_callback', 'ual_shook_widget_update_callback', 8, 4);


/*
 * Get activity for the user - Widget Add Delete
 */
if (!function_exists('ual_shook_widget_added_deleted')) {

    function ual_shook_widget_added_deleted() {
        if ((isset($_POST["add_new"]) && !empty($_POST["add_new"]) && isset($_POST["sidebar"]) && isset($_POST["id_base"])) || isset($_POST["delete_widget"])) {

            $sidebar = $widget = $post_id = $post_title = '';
            $obj_type = "Widget";
            $sidebar_id = sanitize_text_field($_POST["sidebar"]);
            $widget_id_base = sanitize_text_field($_POST["id_base"]);
            $sidebars = isset($GLOBALS['wp_registered_sidebars']) ? $GLOBALS['wp_registered_sidebars'] : false;
            $widget_factory = isset($GLOBALS["wp_widget_factory"]) ? $GLOBALS["wp_widget_factory"] : false;

            if ($widget_factory) {
                foreach ($widget_factory->widgets as $one_widget) {
                    if ($one_widget->id_base == $widget_id_base) {
                        $widget = $one_widget;
                    }
                }
            }
            if ($sidebars) {
                if (isset($sidebars[$sidebar_id])) {
                    $sidebar = $sidebars[$sidebar_id];
                }
                $sidebar_name = $sidebar["name"];
            }
            if ($widget) {
                $post_title = $widget->name;
            }
            if (isset($_POST["delete_widget"])) {
                $action = "Widget deleted";
            } else {
                $action = "Widget added";
            }
            $post_title = $sidebar_name . ' : ' . $post_title;
            ual_get_activity_function($action, $obj_type, $post_id, $post_title);
        }
    }

}
add_action("sidebar_admin_setup", 'ual_shook_widget_added_deleted');


/*
 * Input validation function
 *
 * @param string $data input data
 */
if (!function_exists('ual_test_input')) {

    function ual_test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

}

if (!function_exists('ual_admin_notice_message')) {

    /**
     * Display success or error message
     *
     * @param string $class
     * @param string $message
     * @return string message with HTML
     */
    function ual_admin_notice_message($class, $message) {
        ?>
        <div class="<?php echo $class; ?> is-dismissible notice settings-error">
            <p><?php echo $message; ?></p>
        </div>
        <?php
    }

}

add_action('init', 'ual_filter_user_role');
/**
 * Filter user Roles
 *
 */
if (!function_exists('ual_filter_user_role')):

    function ual_filter_user_role() {
        $paged = 1;
        $admin_url = admin_url('admin.php?page=general_settings_menu');
        $display = '';
        $search = '';
        if (isset($_POST['user_role'])) {
            $display = sanitize_text_field($_POST['user_role']);
        }
        if (isset($_POST['btn_filter_user_role'])) {
            $display = sanitize_text_field($_POST['user_role']);
            $header_uri = $admin_url . "&paged=$paged&display=$display&txtsearch=$search";
            header("Location: " . $header_uri, true);
            exit();
        }
        if (isset($_POST['btnSearch_user_role'])) {
            $search = sanitize_text_field($_POST['txtSearchinput']);
            $header_uri = $admin_url . "&paged=$paged&display=$display&txtsearch=$search";
            header("Location: " . $header_uri, true);
            exit();
        }
    }

endif;

/**
 * Admin scripts
 */
if (!function_exists('ual_admin_scripts')) {

    function ual_admin_scripts() { ?>
        <script>
            var ajaxurl = "<?php echo admin_url('admin-ajax.php'); ?>";
        </script><?php
        $screen = get_current_screen();
        $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/uplogger/uplogger.php', $markup = true, $translate = true);

        wp_register_style('ual-style-css', plugins_url('css/style.css', __FILE__));
        wp_enqueue_style('ual-style-css');
        wp_enqueue_style('wp-jquery-ui-dialog');

        wp_register_script('custom_wp_admin_js', plugins_url('js/admin_script.js', __FILE__), array('jquery-ui-dialog'));
        wp_enqueue_script('custom_wp_admin_js');
        
        if (is_rtl()) {
            wp_enqueue_style('ual-style_rtl-css', plugins_url('css/style_rtl.css', __FILE__));
        }
    }

    

}
add_action('admin_enqueue_scripts', 'ual_admin_scripts');
