<?php
/*
 * Plugin Name:       UpLogger
 * Description:       Log the activity of users and Upload Files. Group C Members: Osama Bajaber, Courtney Duquette, Aishwarya Ramesh Nagarajan, Danny Nsouli, Devyani Raghuwanshi, Harshvardhan Verma
 * Author:            CSCI 6548 Group C
 * Version:           1.0.0
 * License:           GPLv2 or later
 * 
 * Text Domain:       uplogger
 * Domain Path:       /languages/
 */

/*
 * Exit if accessed directly
 */
if (!defined('ABSPATH')) {
    exit;
}

/*
 * Define variables
 */
define('UAL_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('UAL_PLUGIN_URL', plugin_dir_url(__FILE__));
include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
if(!function_exists('is_plugin_active')) {
    require_once( ABSPATH . WPINC . '/pluggable.php' );
}
include(UAL_PLUGIN_DIR . 'user_functions.php');
add_action('admin_init', 'ual_filter_data');
add_filter('plugin_action_links_' . dirname(plugin_basename(__FILE__)), 'uplogger_plugin_links');

/**
 * Load plugin text domain (user-activity-log)
 */
add_action('plugins_loaded', 'load_text_domain_uplogger');

if (!function_exists('load_text_domain_uplogger')) {

    function load_text_domain_uplogger() {
        load_plugin_textdomain('user-activity-log', false, dirname(plugin_basename(__FILE__)) . '/languages/');
    }

}

/**
 * function for set the value in header
 */
if (!function_exists('ual_filter_data')):

    function ual_filter_data() {

        $admin_url = admin_url('admin.php').'?page=user_action_log';
        $paged = isset($_POST['paged']) ? intval($_POST['paged']) : 1;
        $u_role = $u_name = $o_type = $txtSearch = "";
        
        $txtSearch = isset($_POST['txtSearchinput']) ? sanitize_text_field($_POST['txtSearchinput']) : '';
        
        if (isset($_POST['role']) && $_POST['role'] != '0') {
            $u_role = sanitize_text_field($_POST['role']);
        }
        if (isset($_POST['user']) && $_POST['user'] != '0') {
            $u_name = sanitize_text_field($_POST['user']);
        }
        if (isset($_POST['post_type']) && $_POST['post_type'] != '0') {
            $o_type = sanitize_text_field($_POST['post_type']);
        }
        
        // For filtering data
        if (isset($_POST['btn_filter']) && !empty($_POST['btn_filter'])) {
            header("Location: $admin_url&paged=$paged&userrole=$u_role&username=$u_name&type=$o_type&txtsearch=$txtSearch", true);
            exit();
        }
        if (isset($_POST['btnSearch']) && !empty($_POST['btnSearch'])) {
            header("Location: $admin_url&paged=$paged&userrole=$u_role&username=$u_name&type=$o_type&txtsearch=$txtSearch", true);
            exit();
        }
    }

endif;
add_action('admin_menu', 'ual_user_activity');

/*
 * for creating admin side pages
 */
if (!function_exists('ual_user_activity')):

    function ual_user_activity() {
        add_menu_page(__('UpLogger', 'uplogger'), __('UpLogger', 'uplogger'), 'manage_options', 'uplogger', 'ual_user_activity_function', 'dashicons-admin-users');
    }

endif;

/*
 * Display all the user activity log data
 */

if (!function_exists('ual_user_activity_function')):

    function ual_user_activity_function() {
        global $wpdb;
        $paged = $total_pages = 1;
        $srno = 0;
        $user = get_current_user_id();
        $screen = get_current_screen();
        $recordperpage = 10;
        if (isset($_GET['page']) && absint($_GET['page'])) {
            $recordperpage = absint($_GET['page']);
        } elseif (isset($limit)) {
            $recordperpage = $limit;
        } else {
            $recordperpage = get_option('posts_per_page');
        }
        if (!isset($recordperpage) || empty($recordperpage)) {
            $recordperpage = 10;
        }
        if (!isset($limit) || empty($limit)) {
            $limit = 10;
        }
        $table_name = $wpdb->prefix . "ualp_user_activity";
        $where = "where 1=1";
        $u_role = $u_name = $o_type = "";

        if (isset($_GET['paged']))
            $paged = intval($_GET['paged']);

        $offset = ($paged - 1) * $recordperpage;
        $us_role = $us_name = $ob_type = $searchtxt = "";
        if (isset($_GET['userrole']) && $_GET['userrole'] != "") {
            $us_role = sanitize_text_field($_GET['userrole']);
            $where.=" and user_role='$us_role'";
        }
        if (isset($_GET['username']) && $_GET['username'] != "") {
            $us_name = sanitize_text_field($_GET['username']);
            $where.=" and user_name='$us_name'";
        }
        if (isset($_GET['type']) && $_GET['type'] != "") {
            $ob_type = sanitize_text_field($_GET['type']);
            $where.=" and object_type='$ob_type'";
        }
        if (isset($_GET['txtsearch']) && $_GET['txtsearch'] != "") {
            $searchtxt = sanitize_text_field($_GET['txtsearch']);
            $where.=" and user_name like '%".$searchtxt."%' or user_role like '%".$searchtxt."%' or object_type like '%".$searchtxt."%' or action like '%".$searchtxt."%'";
        }

        // query for display all the user activity data start
        $select_query = $get_data = $total_items_query = $total_items = "";
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'")) {
            $select_query = "SELECT * from $table_name $where ORDER BY modified_date desc LIMIT $offset,$recordperpage";
            $get_data = $wpdb->get_results($select_query);
            $total_items_query = "SELECT count(*) FROM $table_name $where";
            $total_items = $wpdb->get_var($total_items_query, 0, 0);
        }

        // query for display all the user activity data end
        // for pagination
        $total_pages = ceil($total_items / $recordperpage);
        $next_page = (int) $paged + 1;
        if ($next_page > $total_pages)
            $next_page = $total_pages;
        $prev_page = (int) $paged - 1;
        if ($prev_page < 1)
            $prev_page = 1;
        ?>
        <div class="wrap">
            <h2><?php _e('UpLogger User Activity Log', 'user-activity-log'); ?></h2>
            <form method="POST" action="<?php echo admin_url('admin.php') . "?" . $_SERVER['QUERY_STRING']; ?>" class="frm-user-activity">
                <div class="tablenav top">
                    <div class="wp-filter">
                        <div class="ual-filter-cover">
                            <!-- Drop down menu for Role Start -->
                            <div class="alignleft actions">
                                <select name="role">
                                    <option selected value="0"><?php _e('All Roles', 'user-activity-log'); ?></option>
                                    <?php
                                    $role_query = "SELECT distinct user_role from $table_name";
                                    $get_roles = $wpdb->get_results($role_query);
                                    foreach ($get_roles as $role) {
                                        $user_role = $role->user_role;
                                        if ($user_role != "") {
                                            ?>
                                            <option value="<?php echo $user_role; ?>" <?php echo selected($us_role, $user_role); ?>><?php echo ucfirst($user_role); ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <!-- Drop down menu for Role end -->

                            <!-- Drop down menu for User Start -->
                            <div class="alignleft actions">
                                <select name="user" class="sol-dropdown">
                                    <option selected value="0"><?php _e('All Users', 'user-activity-log'); ?></option>
                                    <?php
                                    $username_query = "SELECT distinct user_name from $table_name";
                                    $get_username = $wpdb->get_results($username_query);
                                    foreach ($get_username as $username) {
                                        $user_name = $username->user_name;
                                        if ($user_name != "") {
                                            ?>
                                            <option value="<?php echo $user_name; ?>" <?php echo selected($us_name, $user_name); ?>><?php echo ucfirst($user_name); ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <!-- Drop down menu for User end -->

                            <!-- Drop down menu for Post type Start -->
                            <div class="alignleft actions">
                                <select name="post_type">
                                    <option selected value="0"><?php _e('All Types', 'user-activity-log'); ?></option>
                                    <?php
                                    $object_type_query = "SELECT distinct object_type from $table_name";
                                    $get_type = $wpdb->get_results($object_type_query);
                                    foreach ($get_type as $type) {
                                        $object_type = $type->object_type;
                                        if ($object_type != "") {
                                            ?>
                                            <option value="<?php echo $object_type; ?>" <?php echo selected($ob_type, $object_type); ?>><?php echo ucfirst($object_type); ?></option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>                            
                            </div>
                            <!-- Drop down menu for Post type end -->

                            <div>
                                <input class="button-secondary action sol-filter-btn" type="submit" value="<?php _e('Filter', 'user-activity-log'); ?>" name="btn_filter">
                            </div>
                        </div>

                        <!-- Search Box start -->
                        <div class="sol-search-div">
                            <p class="search-box">
                                <label class="screen-reader-text" for="search-input"><?php _e('Search', 'user-activity-log'); ?> :</label>
                                <input id="user-search-input" type="search" placeholder="<?php _e('User, Role, Action', 'user-activity-log'); ?>" value="<?php echo $searchtxt; ?>" name="txtSearchinput">
                                <input id="search-submit" class="button" type="submit" value="<?php esc_attr_e('Search', 'user-activity-log'); ?>" name="btnSearch">
                            </p>
                        </div>
                        <!-- Search Box end -->
                    </div>
                    <!-- Top pagination start -->
                    <div class="tablenav-pages">
                        <?php $items = $total_items . ' ' . _n('item', 'items', $total_items, 'user-activity-log'); ?>
                        <span class="displaying-num"><?php echo $items; ?></span>
                        <div class="tablenav-pages" <?php
                        if ((int) $total_pages <= 1) {
                            echo 'style="display:none;"';
                        }
                        ?>>
                            <span class="pagination-links">
                                <?php if ($paged == '1') { ?>
                                    <span class="tablenav-pages-navspan" aria-hidden="true">&laquo;</span>
                                    <span class="tablenav-pages-navspan" aria-hidden="true">&lsaquo;</span>
                                <?php } else {
                                    ?>
                                    <a class="first-page <?php if ($paged == '1') echo 'disabled'; ?>" href="<?php echo admin_url('admin.php?page=user_action_log').'&paged=1&userrole=' . $us_role . '&username=' . $us_name . '&type=' . $ob_type . '&txtsearch=' . $searchtxt; ?>" title="<?php _e('Go to the first page', 'user-activity-log'); ?>">&laquo;</a>
                                    <a class="prev-page <?php if ($paged == '1') echo 'disabled'; ?>" href="<?php echo admin_url('admin.php?page=user_action_log').'&paged=' . $prev_page . '&userrole=' . $us_role . '&username=' . $us_name . '&type=' . $ob_type . '&txtsearch=' . $searchtxt; ?>" title="<?php _e('Go to the previous page', 'user-activity-log'); ?>">&lsaquo;</a>
                                <?php } ?>
                                <span class="paging-input">
                                    <input class="current-page" type="text" size="1" value="<?php echo $paged; ?>" name="paged" title="<?php _e('Current page', 'user-activity-log'); ?>"> <?php _e('of', 'user-activity-log'); ?>
                                    <span class="total-pages"><?php echo $total_pages; ?></span>
                                </span>
                                <a class="next-page <?php if ($paged == $total_pages) echo 'disabled'; ?>" href="<?php echo admin_url('admin.php?page=user_action_log').'&paged=' . $next_page . '&userrole=' . $us_role . '&username=' . $us_name . '&type=' . $ob_type . '&txtsearch=' . $searchtxt; ?>" title="<?php _e('Go to the next page', 'user-activity-log'); ?>">&rsaquo;</a>
                                <a class="last-page <?php if ($paged == $total_pages) echo 'disabled'; ?>" href="<?php echo admin_url('admin.php?page=user_action_log').'&paged=' . $total_pages . '&userrole=' . $us_role . '&username=' . $us_name . '&type=' . $ob_type . '&txtsearch=' . $searchtxt; ?>" title="<?php _e('Go to the last page', 'user-activity-log'); ?>">&raquo;</a>
                            </span>
                        </div>
                    </div>
                    <!-- Top pagination end -->
                </div>
                <!-- Table for display user action start -->
                <table class="widefat post fixed striped" cellspacing="0">
                    <thead>
                        <tr>
                            <th style="width: 25px" scope="col" class="manage-column column-check"><?php _e('No.', 'user-activity-log'); ?></th>
                            <th scope="col"><?php _e('Date', 'user-activity-log'); ?></th>
                            <th scope="col"><?php _e('Author', 'user-activity-log'); ?></th>
                            <th scope="col"><?php _e('IP Address', 'user-activity-log'); ?></th>
                            <th scope="col"><?php _e('Type', 'user-activity-log'); ?></th>
                            <th scope="col"><?php _e('Action', 'user-activity-log'); ?></th>
                            <th scope="col" colspan="2"><?php _e('Description', 'user-activity-log'); ?></th>
                            <th scope="col"></th>
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th style="width: 25px" scope="col" class="manage-column column-check"><?php _e('No.', 'user-activity-log'); ?></th>
                            <th scope="col"><?php _e('Date', 'user-activity-log'); ?></th>
                            <th scope="col"><?php _e('Author', 'user-activity-log'); ?></th>
                            <th scope="col"><?php _e('IP Address', 'user-activity-log'); ?></th>
                            <th scope="col"><?php _e('Type', 'user-activity-log'); ?></th>
                            <th scope="col"><?php _e('Action', 'user-activity-log'); ?></th>
                            <th scope="col" colspan="2"><?php _e('Description', 'user-activity-log'); ?></th>
                            <th scope="col"></th>
                        </tr>
                    </tfoot>
                    <tbody>
                        <?php
                        if ($get_data) {
                            $srno = 1 + $offset;
                            foreach ($get_data as $data) {
                                ?>
                                <tr>
                                    <td class="check column-check"><?php
                                        echo $srno;
                                        $srno++;
                                        ?></td>
                                    <td><?php
                                        $modified_date = strtotime($data->modified_date);
                                        $date_format = get_option('date_format');
                                        $time_format = get_option('time_format');
                                        echo $date = date($date_format, $modified_date);
                                        echo " ";
                                        echo $time = date($time_format, $modified_date);
                                        ?></td>
                                    <td class="user_id column-user_id" data-colname="Author">
                                        <a href="<?php echo get_edit_user_link($data->user_id); ?>">
                                            <?php echo get_avatar($data->user_id, 40); ?>
                                            <span><?php echo ucfirst($data->user_name); ?></span>
                                        </a><br>
                                        <small><?php echo ucfirst($data->user_role); ?></small><br>
                                        <?php echo $data->user_email; ?>
                                    </td>
                                    <td><?php echo $data->ip_address; ?></td>
                                    <td><?php echo ucfirst($data->object_type); ?></td>
                                    <td><?php echo ucfirst($data->action); ?></td>
                                    <td class="column-description" colspan="2">
                                        <?php if (($data->object_type == "post" || $data->object_type == "page") && $data->action != 'post deleted' && $data->action != 'page deleted') { ?>
                                            <a href="<?php echo get_permalink($data->post_id); ?>">
                                                <?php echo ucfirst($data->post_title); ?>
                                            </a><?php
                                        } else {
                                            echo ucfirst($data->post_title);
                                        }
                                        ?>
                                    </td>
                                </tr>
                                <?php
                            }
                        } else {
                            echo '<tr class="no-items">';
                            echo '<td class="colspanchange" colspan="9">' . __('No record found.', 'user-activity-log') . '</td>';
                            echo '</tr>';
                        }
                        ?>
                    </tbody>
                </table>
                <!-- Table for display user action end -->
                <!-- Bottom pagination start -->
                <div class="tablenav top">
                    <div class="tablenav-pages">
                        <span class="displaying-num"><?php echo $items; ?></span>
                        <div class="tablenav-pages" <?php
                        if ((int) $total_pages <= 1) {
                            echo 'style="display:none;"';
                        }
                        ?>>
                            <span class="pagination-links">
                                <?php if ($paged == '1') { ?>
                                    <span class="tablenav-pages-navspan" aria-hidden="true">&laquo;</span>
                                    <span class="tablenav-pages-navspan" aria-hidden="true">&lsaquo;</span>
                                <?php } else {
                                    ?>
                                    <a class="first-page <?php if ($paged == '1') echo 'disabled'; ?>" href="<?php echo admin_url('admin.php?page=user_action_log').'&paged=1&userrole=' . $us_role . '&username=' . $us_name . '&type=' . $ob_type . '&txtsearch=' . $searchtxt; ?>" title="<?php _e('Go to the first page', 'user-activity-log'); ?>">&laquo;</a>
                                    <a class="prev-page <?php if ($paged == '1') echo 'disabled'; ?>" href="<?php echo admin_url('admin.php?page=user_action_log').'&paged=' . $prev_page . '&userrole=' . $us_role . '&username=' . $us_name . '&type=' . $ob_type . '&txtsearch=' . $searchtxt; ?>" title="<?php _e('Go to the previous page', 'user-activity-log'); ?>">&lsaquo;</a>
                                <?php } ?>
                                <span class="paging-input">
                                    <span class="current-page" title="<?php _e('Current page', 'user-activity-log'); ?>"><?php echo $paged; ?></span> <?php _e('of', 'user-activity-log'); ?>
                                    <span class="total-pages"><?php echo $total_pages; ?></span>
                                </span>
                                <a class="next-page <?php if ($paged == $total_pages) echo 'disabled'; ?>" href="<?php echo admin_url('admin.php?page=user_action_log').'&paged=' . $next_page . '&userrole=' . $us_role . '&username=' . $us_name . '&type=' . $ob_type . '&txtsearch=' . $searchtxt; ?>" title="<?php _e('Go to the next page', 'user-activity-log'); ?>">&rsaquo;</a>
                                <a class="last-page <?php if ($paged == $total_pages) echo 'disabled'; ?>" href="<?php echo admin_url('admin.php?page=user_action_log').'&paged=' . $total_pages . '&userrole=' . $us_role . '&username=' . $us_name . '&type=' . $ob_type . '&txtsearch=' . $searchtxt; ?>" title="<?php _e('Go to the last page', 'user-activity-log'); ?>">&raquo;</a>
                            </span>
                        </div>
                    </div>
                </div>
                <!-- Bottom pagination end -->
            </form>

        </div>
        <?php
    }

endif;

/*
 * Delete activity log as per selected days
 */
if (!function_exists('uplogger_delete_log')) {

    function uplogger_delete_log() {
        global $wpdb;
        $getLogSpan = "";
        $getLogSpan = get_option('ualpKeepLogsDay');
        $table_name = $wpdb->prefix . "ualp_user_activity";
        if (!empty($getLogSpan)) {
            $wpdb->query("DELETE FROM $table_name WHERE modified_date < NOW() - INTERVAL $getLogSpan DAY");
        }
    }

}
add_action('init', 'uplogger_delete_log');


add_action('activated_plugin', 'ual_activated_plugin');
if(!function_exists('ual_activated_plugin')) {
    function ual_activated_plugin($plugin) {
        if( $plugin == dirname(plugin_basename( __FILE__ )) ) {
            $ual_is_optin = get_option('ual_is_optin');
            if($ual_is_optin == 'yes' || $ual_is_optin == 'no') {
                exit( wp_redirect( admin_url( 'admin.php?page=user_action_log' ) ) );
            }
            else {
                exit( wp_redirect( admin_url( 'admin.php?page=user_welcome_page' ) ) );
            }
        }
    }
}
